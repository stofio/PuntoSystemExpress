<?php

echo 'Access denied';

?>