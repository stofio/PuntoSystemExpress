<?php $page_title = 'Express'; ?>
<?php require_once 'include/header.php'; ?> 


<?php include $_SERVER['DOCUMENT_ROOT'].'/tmp/content-home.php'; ?> 

<?php //require_once 'include/footer.php'; ?>

<?php include $_SERVER['DOCUMENT_ROOT'].'/include/footer.php'; ?> 