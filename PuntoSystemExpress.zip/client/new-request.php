<?php $page_title = 'New Request'; ?>
<?php require_once 'include/header.php'; ?>
<link href="/vendor/bootstrap-datetimepicker-master/bootstrap-datetimepicker.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="/vendor/bootstrap-datetimepicker-master/bootstrap-datetimepicker.min.js"></script>

  
<?php include $_SERVER['DOCUMENT_ROOT'].'/tmp/content-new-ship.php'; ?>


<script src="/client/js/new-request.js"></script>

 
<?php include $_SERVER['DOCUMENT_ROOT'].'/include/footer.php'; ?>  

